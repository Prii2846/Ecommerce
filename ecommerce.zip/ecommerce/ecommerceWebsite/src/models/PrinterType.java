package models;

public enum PrinterType {
    HP,CANON,EPSON
    
}
