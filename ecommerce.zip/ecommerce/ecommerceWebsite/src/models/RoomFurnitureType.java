package models;

public enum RoomFurnitureType {
    BED,SOFA,WARDROBE
    
}
