package models;

 public class Product{
    private int id;
    private String name;
    private double price;
    private int stock;
    private ProductType productType;
   

    public Product(int id,String name,double price,int stock,ProductType productType){
     this.id = id;
     this.name = name;
     this.price = price;
     this.stock = stock;
     this.productType = productType;

    }
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public double getPrice(){
        return price;
    }
    public int getstock(){
        return stock;
    }
    public ProductType getProductType(){
        return productType;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Product{");
        sb.append("id=").append(id);
        sb.append(", name=").append(name);
        sb.append(", price=").append(price);
        sb.append(", stock=").append(stock);
        sb.append(", productType=").append(productType);
        sb.append('}');
        return sb.toString();
    }
    

}
