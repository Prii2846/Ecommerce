package models;

public class Category {
    private int id;
    private CategoryType categoryType;

   
    public Category(int id,CategoryType categoryType){
        this.id = id;
        this.categoryType = categoryType;

    }

    public Category() {
    }

    public Category(CategoryType categoryType) {
        this.categoryType = categoryType;
    }
    public int getId(){
        return id;
    }
    public void setId(){
        this.id = id;
    }
    public CategoryType getCategory(CategoryType categoryType){
        return categoryType;
    }
    public void setCategoryType(CategoryType categoryType){
        this.categoryType = categoryType;
    }
 
    public String toString() {
        return "Category { " +
               "id=" + id +
               ", categoryType=" + categoryType +
               " }";
    }

    public CategoryType getCategoryType() {
        return categoryType;
    }
 
}
