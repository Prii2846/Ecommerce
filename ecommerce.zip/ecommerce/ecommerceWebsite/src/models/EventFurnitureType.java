package models;

public enum EventFurnitureType {

    CHAIR,TABLE,SOFA
}
