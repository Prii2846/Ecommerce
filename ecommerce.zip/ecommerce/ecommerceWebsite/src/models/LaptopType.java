package models;

public enum LaptopType {
    DELL,HP,LENOVO,APPLE,ASUS
    
}
