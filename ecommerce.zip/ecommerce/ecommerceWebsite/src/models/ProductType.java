package models;

public record ProductType (String mainCategory,String subCategory){

public static final ProductType MOBILES = new ProductType("Electronics", "Mobiles");
public static final ProductType LAPTOPS =  new ProductType("Electronics", "Laptops");
public static final ProductType WEARABLES = new ProductType("Electronics","Wearables");
public static final ProductType PRINTERS = new ProductType("Electronics","Printers");

public static final ProductType ROOM = new ProductType("Furniture","Room");
public static final ProductType OFFICE = new ProductType("Furniture","Office");
public static final ProductType EVENT = new ProductType("Furniture","Event");



    
}
