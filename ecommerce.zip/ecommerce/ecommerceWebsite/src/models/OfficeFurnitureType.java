package models;

public enum OfficeFurnitureType {
    CHAIR,DESK,BOOKSELF
    
}
