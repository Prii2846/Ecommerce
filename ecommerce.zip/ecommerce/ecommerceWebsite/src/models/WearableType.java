package models;

public enum WearableType {
    APPLE_WATCH,BOAT_WATCH
    
}
