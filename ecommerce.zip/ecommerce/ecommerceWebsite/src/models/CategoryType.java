package models;

public enum CategoryType{
    Electronics,
    Furniture;


}