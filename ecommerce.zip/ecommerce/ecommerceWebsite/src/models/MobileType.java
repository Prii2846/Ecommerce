package models;

public enum MobileType {
    OOPO,VIVO,APPLE,SAMSUNG,ONEPLUS

    
}
