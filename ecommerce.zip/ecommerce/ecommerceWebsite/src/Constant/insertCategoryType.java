package Constant;

    public class insertCategoryType {
        public static void inserTable(){
            String insertCategory = """
                    INSERT INTO Categories (category_type) VALUES ('ELECTRONICS'), ('FURNITURE');
                    """;
        }
        
    }
    
    

