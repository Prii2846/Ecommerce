package Constant;
import java.sql.*;
import database.DbConnection;


public class DatabaseInitializer {
    public static void createTables(){
      
        String createProductsTable = """
                CREATE TABLE IF NOT EXISTS Products(
                id INT AUTO_INCREMENT PRIMARY KEY,
                Product_name VARCHAR(200) NOT NULL,
                price DECIMAL(10,2) NOT NULL,
                stock INT NOT NUll,
                category_id INT,
                FOREIGN KEY(category_id) REFERENCES Categories(id)
                )
                """;  
        String createUsersTable ="""
                CREATE TABLE IF NOT EXISTS Users(
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(100) NOT NULL,
                role ENUM('Admin','buyer','seller') NOT NULL
                )
                """;        
        String createOrdersTable = """
                 CREATE TABLE IF NOT EXISTS Orders(
                 id int AUTO_INCREMENT PRIMARY KEY,
                 user_id INT NOT NULL,
                 order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 total_price DECIMAL(10,2) NOT NULL,
                 FOREIGN KEY(user_id) REFERENCES Users(id)
                 )
                 """;    

        String createOrderItemsTable = """
                CREATE TABLE IF NOT EXISTS OrderItems(
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                product_id INT NOT NULL,
                quantity INT NOT NULL,
                FOREIGN KEY(order_id) REFERENCES Orders(id),
                FOREIGN KEY (product_id) REFERENCES Products(id)
                )
                """;
        String createWishlistsTable = """
                CREATE TABLE IF NOT EXISTS Wishlists(
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                product_id INT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES Users(id),
                FOREIGN KEY(product_id) REFERENCES Products(id)
                )
                """;  
                try (Connection connection = DbConnection.getConnection();
                Statement stmt = connection.createStatement()){

                stmt.execute(createProductsTable);
                stmt.execute(createUsersTable);
                stmt.execute(createOrdersTable);
                stmt.execute(createOrderItemsTable);
                stmt.execute(createWishlistsTable);



                System.out.println("All tables created successfully.");
                    
                } catch (Exception e) {
                    System.out.println("Error creating tables: " + e.getMessage());
                }      
        }
        
public static void insertTable(){
        String insertUser ="""
                        
                     
INSERT INTO Users (username, password, role) VALUES ('admin123', 'Admin@123', 'Admin');


INSERT INTO Users (username, password, role) VALUES ('seller123', 'Seller@123', 'Seller');

INSERT INTO Users (username, password, role) VALUES ('buyer123', 'Buyer@123', 'Buyer');
 """;
}

    }
    

