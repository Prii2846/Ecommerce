package Constant;
import database.DbConnection;
import java.sql.*;



public class createCategory {
    public static void createCategory(){
        String createCategoriesTable = """
                CREATE TABLE IF NOT EXISTS Categories(
                id INT AUTO_INCREMENT PRIMARY KEY,
               category_type ENUM('ELECTRONICS', 'FURNITURE') NOT NULL
                )
                """;
        try (Connection connection = DbConnection.getConnection();
        Statement stmt = connection.createStatement()){

        stmt.execute(createCategoriesTable);
                
    } catch (Exception e) {
        System.out.println("Error creating tables: " + e.getMessage());
    }     
    
}
}
