// package DbRepository;
// import java.sql.*;
// import database.DbConnection;



// public class UserAuthenticator {
    
//     public static boolean authenticate (String username,String  password,String role) throws SQLException{
//         String q = "SELECT * FROM Users WHERE username =? AND password=? AND role =?";
//         try (Connection connection = DbConnection.getConnection();
//         PreparedStatement pstmt = connection.prepareStatement(q)){
//             pstmt.setString(1,username.trim());
//             pstmt.setString(2,password.trim());
//             pstmt.setString(3, role);

//             ResultSet rs = pstmt.executeQuery();
//             return rs.next();

//         }catch(SQLException e){
//             System.out.println("Error during authentication: " + e.getMessage());
//             return false;

    
//         }
    
          
//     // public static boolean isUserNameExists(String username){
//     //     String q = "SELECT username FROM user WHERE username = ?";
//     //     try(Connection con = DbConnection.getConnection();
//     //     PreparedStatement pstmt = con.prepareStatement(q)){
//     //         pstmt.setString(1,username);
//     //         ResultSet rs = pstmt.executeQuery();
//     //         return rs.next();

            

//     //     }catch(SQLException e){
//     //         System.out.println("Error checking username " + e.getMessage());
//     //         return false;
//     //     }

   
// }

// }