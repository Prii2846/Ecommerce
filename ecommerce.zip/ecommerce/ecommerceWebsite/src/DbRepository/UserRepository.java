package DbRepository;
import java.sql.*;
import database.DbConnection;
import models.User;

public class UserRepository {
    public static boolean registerUser(User user){
    String q = "INSERT INTO USERS(username,password,role) VALUES(?,?,?)";
    try (Connection connection = DbConnection.getConnection();
    PreparedStatement pstmt =  connection.prepareStatement(q)){
        pstmt.setString(1,user.getUsername());
        pstmt.setString(2,user.getPassword());
        pstmt.setString(3,user.getRole());

        int rowAffected = pstmt.executeUpdate();
        return rowAffected>0;

        
    } catch (SQLException e) {
        System.out.println("Error during registration" + e.getMessage());
        return false;
    }

    }
    public static boolean isUsernameExists(String username) {
        String query = "SELECT id FROM Users WHERE username = ?";
        try (Connection connection = DbConnection.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            return rs.next(); 
        } catch (SQLException e) {
            System.out.println("Error checking username: " + e.getMessage());
            return false;
        }
    }
    
}
