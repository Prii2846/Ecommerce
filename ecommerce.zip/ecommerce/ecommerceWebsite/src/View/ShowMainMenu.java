package View;
import database.*;
import java.sql.SQLException;
import DbRepository.UserAuthenticator;



public class ShowMainMenu {
    private static final View.InputScanner input = View.InputScanner.getConnection();
    
    static void showMainMenu() throws SQLException{
        while (true) {
            System.out.println(" E-commerce ANT-ZON ");
            System.out.println("1. Admin Login");
            System.out.println("2. Seller Login ");
            System.out.println("3. Buyer Login");
            System.out.println("4. Exit");

            int choice = input.readInt("Enter your choice: ");

            switch(choice){
                case 1 -> handleAdminLogin();
                case 2 -> handleSellerLogin();
                case 3 -> handleBuyerLogin();
                case 4 -> {
                    System.out.println("Thank you for using E-commerce ANT-ZON ");
                    input.close();
                    return;
                }
            default -> System.out.println("Invalid choice! Please try again.");      
            }  
        }
    }

    private static void handleAdminLogin() throws SQLException{
        System.out.println("You are in Admin Login ");
        String username  = input.readString("Enter Admin Username: ");
        String password = input.readString("Enter Admin Password: ");
        
        

        if(UserAuthenticator.authenticate(username,password, "Admin")){
          System.out.println("Admin login successfully");
        }else{
            System.out.println("Invalid admin details! please try again ");
        }

    }

    private static String validateUsername(String prompt){
        String userNameRegex = "^[a-zA-Z0-9]{6,9}$";
        while (true) { 
            System.out.println("Username contain only Alphanumeric ");
            System.out.println("Username must be 6 to 9 characters long ");
            System.out.println("No special characters");
            String username = input.readString(prompt);
            if(username.matches(userNameRegex)){
                return username;
            }else{
                System.out.println("Invalid username! Please try again as per the requirements ");

            }
            
        }
    }
    private static String validatePassword(String prompt) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=]).{8,}$"; 
        while (true) {
            System.out.println("- Password Must be at least 8 characters long.");
            System.out.println("- Password Must include at least 1 uppercase letter.");
            System.out.println("- password Must include at least 1 number.");
            System.out.println("- password Must include at least 1 special character (@, #, $, %, ^, &, +, =, etc.).");
            String password = input.readString(prompt);
            if (password.matches(regex)) {
                return password;
            } else {
                System.out.println("Invalid password! Please try again as per the requirements\n");
            }
        }
    }
    private static void handleSellerLogin() throws SQLException{
        System.out.println("You are in Seller Login ");
        String username = input.readString("Enter Seller Username: ");
        String password = input.readString("Enter Seller Password: ");

        if(UserAuthenticator.authenticate(username, password, "Seller")){
            System.out.println("Seller login successfully");
        }else{
            System.out.println("Invalid Seller details! please try again ");
        }
        }
        private static void handleBuyerLogin() throws SQLException{{
            System.out.println("You are in Buyer Login ");
            String username = input.readString("Enter Buyer Username: ");
            String password = input.readString("Enter Buyer Password: ");
    
            if(UserAuthenticator.authenticate(username, password, "Buyer")){
                System.out.println("Buyer login successfully");
            }else{
                System.out.println("Invalid Buyer details! please try again ");
            }
            }


    }
    
}


