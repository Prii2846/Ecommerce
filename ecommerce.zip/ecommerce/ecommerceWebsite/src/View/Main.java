package View;
import java.sql.SQLException;

import Constant.DatabaseInitializer;

public class Main {
    // private static final View.InputScanner input = Main.InputScanner.getInstance();
    
    public static void main(String[] args) throws SQLException {
        // ShowMainMenu.showMainMenu();
        // DatabaseInitializer.createTables();
    

        try {
            ShowMainMenu.showMainMenu();
            DatabaseInitializer.createTables();
            DatabaseInitializer.insertTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


        
